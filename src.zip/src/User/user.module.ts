import { Module } from "@nestjs/common";


// import { UserModule } from "./user/user.module";

// import { TeamModule } from "./team/team.module";

import { ConfigModule } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "src/prisma/prisma.module";

import { UserController } from "./user.controller";
import { UserService } from "./user.service";
import { JwtStrategy } from "src/auth/jwt.strategy";

@Module({
  imports: [
    // ConfigModule.forRoot({isGlobal: true}),
    JwtModule,
    PrismaModule
    
  ],

  controllers: [UserController],
  providers: [UserService,JwtStrategy],
})
export class UserModule {}
