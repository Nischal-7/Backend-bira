// import { Test, TestingModule } from '@nestjs/testing';
// import { UserController } from './user.controller';
// import { UserService } from './user.service';
// import { AuthDto } from '../auth/dto/auth.dto';
// import { ResetDto } from '../auth/dto/resetPassword.dto';
// import { Request, Response } from 'express';

// describe('UserController', () => {
//   let controller: UserController;
//   let service: UserService;

//   beforeEach(async () => {
//     const module: TestingModule = await Test.createTestingModule({
//       controllers: [UserController],
//       providers: [UserService],
//     }).compile();

//     controller = module.get<UserController>(UserController);
//     service = module.get<UserService>(UserService);
//   });

//   describe('addUser', () => {
//     it('should add a new user', async () => {
//       const req = {} as Request;
//       const res = {} as Response;
//       const user: AuthDto = {
//           first_name: 'testuser1',
//           last_name: 'testuser',
//           role: 'ADMIN',
//           email: 'abhi@gmail.com',
//           password: 'testpass',
//           teamId: 1,
//           id: 0
//       };
//       jest.spyOn(service, 'inserUser').mockResolvedValue(user);

//       const result = await controller.addUser(user, req, res);

//       expect(result).toEqual(user);
//       expect(service.inserUser).toHaveBeenCalledWith(user, req, res);
//     });
//   });

//   describe('getUser', () => {
//     it('should return all users', async () => {
//       const req = {} as Request;
//       const res = {} as Response;
//       const users: AuthDto[] = [
//         {
//             first_name: 'testuser2',
//             last_name: 'testuser',
//             role: 'ADMIN',
//             email: 'abhi@gmail.com',
//             password: 'testpass',
//             teamId: 1,
//             id: 1
//         },
//         {
//             first_name: 'testuser3',
//             last_name: 'testuser',
//             role: 'ADMIN',
//             email: 'abhi@gmail.com',
//             password: 'testpass',
//             teamId: 1,
//             id: 2
//         },
//       ];
//       jest.spyOn(service, 'getAll').mockResolvedValue(users);

//       const result = await controller.getUser(req, res);

//       expect(result).toEqual(users);
//       expect(service.getAll).toHaveBeenCalledWith(req, res);
//     });
//   });

//   describe('getUserById', () => {
//     it('should return a user by ID', async () => {
//       const req = {} as Request;
//       const res = {} as Response;
//       const user: AuthDto = {
//         first_name: 'testuser1',
//           last_name: 'testuser',
//           role: 'ADMIN',
//           email: 'abhi@gmail.com',
//           password: 'testpass',
//           teamId: 1,
//           id: 0
//       };
//       jest.spyOn(service, 'getUser').mockResolvedValue(user);

//       const result = await controller.getUserById(1, req, res);

//       expect(result).toEqual(user);
//       expect(service.getUser).toHaveBeenCalledWith(1, req, res);
//     });
//   });

//   describe('resetPassword', () => {
//     it('should reset a user password', async () => {
//       const req = {} as Request;
//       const res = {} as Response;
//       const reset: ResetDto = {
//         email: 'testuser@example.com',
//         oldPassword: 'oldpass',
//         newPassword: 'newpass',
//       };
//       const user: AuthDto = {
//         first_name: 'testuser1',
//           last_name: 'testuser',
//           role: 'ADMIN',
//           email: 'abhi@gmail.com',
//           password: 'testpass',
//           teamId: 1,
//           id: 0
//       };
//       jest.spyOn(service, 'resetUser').mockResolvedValue(user);

//       const result = await controller.resetPassword(reset, req, res);

//       expect(result).toEqual(user);
//       expect(service.resetUser).toHaveBeenCalledWith(reset, req, res);
//     });
//   });
// });

// import { Test, TestingModule } from '@nestjs/testing';
// import { UserController } from './user.controller';
// import { UserService } from './user.service';
// import { Request, Response } from 'express';

// describe('UserController', () => {
//   let userController: UserController;
//   let userService: UserService;

//   beforeEach(async () => {
//     const app: TestingModule = await Test.createTestingModule({
//       controllers: [UserController],
//       providers: [UserService],
//     }).compile();

//     userService = app.get<UserService>(UserService);
//     userController = app.get<UserController>(UserController);
//   });

//   describe('getUserById', () => {
//     it('should return a user with the specified id', async () => {
//       const req = {} as Request;
//       const res = {} as Response;

//       const mockUser = {
//         id: 1,
//         name: 'John Doe',
//         email: 'john.doe@example.com',
//       };

//       jest.spyOn(userService, 'getUser').mockImplementation(async () => mockUser);

//       const result = await userController.getUserById(1, req, res);

//       expect(result).toEqual(mockUser);
//     });
//   });
// });


const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()
const userService = require('./userService')

describe('getUser function', () => {
  it('should return a user if one is found', async () => {
    const mockRequest = {}
    const mockResponse = {
      status: jest.fn(() => mockResponse),
      send: jest.fn(),
    }
    const mockFoundUser = {
      id: 1
    }
    jest.spyOn(prisma.user, 'findUnique').mockResolvedValueOnce(mockFoundUser)

    await userService.getUser(1, mockRequest, mockResponse)

    expect(mockResponse.status).toHaveBeenCalledWith(200)
    expect(mockResponse.send).toHaveBeenCalledWith({
      message: mockFoundUser,
    })
  })

  it('should return an error message if no user is found', async () => {
    const mockRequest = {}
    const mockResponse = {
      status: jest.fn(() => mockResponse),
      send: jest.fn(),
    }
    jest.spyOn(prisma.user, 'findUnique').mockResolvedValueOnce(null)

    await userService.getUser(1, mockRequest, mockResponse)

    expect(mockResponse.status).toHaveBeenCalledWith(201)
    expect(mockResponse.send).toHaveBeenCalledWith({
      message: 'User not found',
    })
  })

  it('should return an error message if an error occurs', async () => {
    const mockRequest = {}
    const mockResponse = {
      status: jest.fn(() => mockResponse),
      send: jest.fn(),
    }
    const mockError = new Error('Something went wrong')
    jest.spyOn(prisma.user, 'findUnique').mockRejectedValueOnce(mockError)

    await userService.getUser(1, mockRequest, mockResponse)

    expect(mockResponse.status).toHaveBeenCalledWith(201)
    expect(mockResponse.send).toHaveBeenCalledWith({
      message: 'Error has been occurred',
      error: mockError,
    })
  })
})
