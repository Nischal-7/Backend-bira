import { Controller, Request, Post, UseGuards, Get, Body, Req, Res, Param, Put } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { AuthDto } from "src/auth/dto/auth.dto";
import { UserService } from "./user.service";
import { ResetDto } from "src/auth/dto/resetPassword.dto";

@ApiTags("User")
@Controller("user")
export class UserController {


    constructor(private readonly userService: UserService) { }

    @Post()
    addUser(@Body() _user: AuthDto, @Req() req, @Res() res) {

        return this.userService.inserUser(_user, req, res);
    }


    @Get()
    getUser(@Req() req, @Res() res) {
        return this.userService.getAll(req, res);
    }


    @Get(':id')
    getUserById(@Param('id') id: number, @Req() req, @Res() res) {
        id = Number(id)
        return this.userService.getUser(id, req, res);
    }


    @Put("resetPassword")
    resetPassword(@Body() _reset: ResetDto, @Req() req, @Res() res) {
        return this.userService.resetUser(_reset, req, res);

    }

}
