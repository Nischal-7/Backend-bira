// // src/audit-logs/audit-logs.service.ts

// import { Injectable } from '@nestjs/common';
// import { PrismaService } from '../prisma/prisma.service';
// import { AuditLog } from '@prisma/client';

// @Injectable()
// export class AuditLogsService {
//   constructor(private prisma: PrismaService) {}

//   async createAuditLog(
//     method: string,
//     actionTable: string,
//     auditUser: string,
//     statusCode: number,
//     changes?: string | null,
//     timestamp?: Date,
//   ): Promise<AuditLog> {
//     return this.prisma.auditLog.create({
//       data: {
//         method,
//         actionTable,
//         auditUser,
//         statusCode,
//         changes,
//         timestamp,
//       },
//     });
//   }
// }

import { Injectable, NestMiddleware } from '@nestjs/common';

import { AuditLog } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class AuditLogsService {
  constructor(private prisma: PrismaService) {}

  async createAuditLog(
    method: string,
    actionTable: string,
    auditUser: string,
    statusCode: number,
    changes?: string | null,
    timestamp?: Date,
  ): Promise<AuditLog> {
    return this.prisma.auditLog.create({
      data: {
        method,
        actionTable,
        auditUser,
        statusCode,
        changes,
        timestamp,
      },
    });
  }
}
