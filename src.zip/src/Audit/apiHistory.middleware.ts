// // apiHistory.middleware.ts

// import { Injectable, NestMiddleware } from '@nestjs/common';
// import { NextFunction, Request, Response } from 'express';
// import { PrismaClient } from '@prisma/client';
// import { PrismaService } from './prisma/prisma.service';
// import { JwtService } from '@nestjs/jwt';

// @Injectable()
// export class ApiHistoryMiddleware implements NestMiddleware {
//   constructor(private prisma: PrismaService, private jwt: JwtService) { }
//   // private prisma = new PrismaClient();

//   async use(req: Request, res: Response, next: NextFunction) {
//     const { method, originalUrl, body, params, query } = req;
//     const start = Date.now();

//     res.on('finish', async () => {
//       const end = Date.now();
//       const responseTime = end - start;
//       const apiHistory = {
//         request: JSON.stringify({ method, originalUrl, body, params, query }),
//         response: JSON.stringify({ statusCode: res.statusCode, responseTime, headers: res.getHeaders(), body: res.getHeaders() }),
//       };
//       await this.prisma.apiHistory.create({ data: apiHistory });
//     });

//     next();
//   }
// }
// src/audit-logs/audit-logs.middleware.ts

// import { Injectable, NestMiddleware } from '@nestjs/common';
// import { Request, Response } from 'express';
// import { AuditLogsService } from './audit.service';
// // import { AuditLogsService } from './audit-logs.service';

// @Injectable()
// export class AuditLogsMiddleware implements NestMiddleware {
//     constructor(private readonly auditLogsService: AuditLogsService) {}

//     async use(req: Request, res: Response, next: () => void) {
//       const { method, url, body } = req;
//       const auditUser = 'Unknown'; // Replace with the authenticated user's name
//       const statusCode = res.statusCode;

//       // Extract the action table from the request URL
//       const matches = url.match(/^\/(\w+)/);
//       const actionTable = matches ? matches[1] : 'Unknown';

//       // Convert the request body to a string
//       const changes = JSON.stringify(body);

//       // Create a new AuditLog record for this request
//       await this.auditLogsService.createAuditLog(
//         method.toUpperCase(),
//         actionTable,
//         auditUser,
//         statusCode,
//         changes,
//       );

//       next();
//     }
//   }
//   


import { Injectable, NestMiddleware } from '@nestjs/common';
import { AuditLogsService } from './audit.service';
import { ExtractJwt } from 'passport-jwt';
import { JwtService } from '@nestjs/jwt';
import { jwtSecret } from 'src/utils/contants';
// import { AuditLogsService } from './audit-logs.service';

@Injectable()
export class AuditMiddleware implements NestMiddleware {
    constructor(private auditLogsService: AuditLogsService, private jwtService: JwtService) { }

    async use(req: any, res: any, next: () => void) {
        const token = ExtractJwt.fromAuthHeaderAsBearerToken()(req)
        const user = await this.getUserDetailsFromJWT(this.jwtService, token);
        console.log(user)
        const method = req.method;
        const actionTable = req.originalUrl.split('/')[1];
        const auditUser = user["username"]; // assuming user is authenticated and their username is stored in req.user
        const statusCode = res.statusCode;
        const changes = JSON.stringify(req.body);
        const timestamp = new Date();

        await this.auditLogsService.createAuditLog(
            method,
            actionTable,
            auditUser,
            statusCode,
            changes,
            timestamp,
        );

        next();
    }

    async getUserDetailsFromJWT(
        jwtService: JwtService,
        bearerToken: string
    ) {
        if (bearerToken !== undefined && bearerToken !== null) {
            let token = bearerToken.substring(7);
            return await jwtService.decode(token);
        }
        return {
            username: "",
        };
    }
}
