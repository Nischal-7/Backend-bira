// import { Module } from "@nestjs/common";


// // import { UserModule } from "./user/user.module";

// // import { TeamModule } from "./team/team.module";

// import { ConfigModule } from "@nestjs/config";
// import { JwtModule } from "@nestjs/jwt";
// import { PrismaModule } from "src/prisma/prisma.module";
// import { JwtStrategy } from "src/auth/jwt.strategy";
// import { AuditLogsController } from "./audit.controller";
// import { AuditLogsService } from "./audit.service";

// @Module({
//   imports: [
//     // ConfigModule.forRoot({isGlobal: true}),
//     // UserModule,
//     // TeamModule,
//     JwtModule,
//     PrismaModule
//   ],

//   controllers: [AuditLogsController],
//   providers: [AuditLogsService,JwtStrategy],
// })
// export class AuditLogModule {}
