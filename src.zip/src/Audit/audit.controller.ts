// // import { Body, Controller, Post } from '@nestjs/common';
// // import { ApiOperation, ApiTags } from '@nestjs/swagger';
// // import { PrismaService } from 'src/prisma/prisma.service';
// // import { AuditDto } from './auth/dto/audit.dto';

// // @ApiTags('API History')
// // @Controller('api-history')
// // export class ApiHistoryController {
// //     constructor(private readonly prisma: PrismaService) { }

// //     @Post()
// //     @ApiOperation({ summary: 'Create a new API history entry' })
// //     async create(@Body() data: AuditDto) {
// //         return this.prisma.apiHistory.create({
// //             data: {
// //                 method:data.method,
// //                 changeJson:data.changeJson,


// //             }
// //         });
// //     }
// // }
// // import { Controller, Post, Body } from '@nestjs/common';
// // import { ApiTags } from '@nestjs/swagger';
// // import { PrismaService } from './prisma/prisma.service';
// // import { AuditDto } from './auth/dto/audit.dto';
// // import { PrismaService } from 'src/prisma.service';
// // import { CreateApiHistoryDto } from './dto/create-api-history.dto';

// // @ApiTags('api-history')
// // @Controller('api-history')
// // export class ApiHistoryController {
// //   constructor(private readonly prisma: PrismaService) {}

// //   @Post()
// //   async create(@Body() auditDto: AuditDto) {
// //     const { method, actionTable, changeJson, timestamp, auditUser, statusCode } =
// //     auditDto;

// //     const apiHistory = await this.prisma.audit.create({
// //       data: {
// //         method,
// //         actionTable,
// //         changeJson,
// //         timestamp: new Date(timestamp),
// //         auditUser,
// //         statusCode,
// //       },
// //     });

// //     return apiHistory;
// //   }
// // }


// // import { Body, Controller, Post } from '@nestjs/common';
// // import { ApiTags } from '@nestjs/swagger';
// // import { PrismaService } from 'src/prisma/prisma.service';
// // import { AuditDto } from '../auth/dto/audit.dto';

// // @ApiTags('api-history')
// // @Controller('api-history')
// // export class ApiHistoryController {
// //   constructor(private readonly prisma: PrismaService) {}

// //   @Post()
// //   async create(@Body() auditDto: AuditDto) {
// //     const { method, actionTable, changeJson, timestamp, auditUser, statusCode } =
// //     auditDto;

// //     return this.prisma.audit.create({
// //       data: {
// //         method,
// //         actionTable,
// //         changeJson,
// //         timestamp,
// //         auditUser,
// //         statusCode,
// //       },
// //     });
// //   }
// // }


// import { Controller, Post, Body } from '@nestjs/common';
// import { AuditLogsService } from './audit.service';

// @Controller('audit-logs')
// export class AuditLogsController {
//   constructor(private auditLogsService: AuditLogsService) {}

//   @Post()
//   async createAuditLog(
//     @Body('method') method: string,
//     @Body('actionTable') actionTable: string,
//     @Body('changes') changes: string,
//     @Body('auditUser') auditUser: string,
//     @Body('statusCode') statusCode: number,
//   ) {
//     return this.auditLogsService.createAuditLog(
//       method,
//       actionTable,
//       changes,
//       auditUser,
//       statusCode,
//     );
//   }
// }
