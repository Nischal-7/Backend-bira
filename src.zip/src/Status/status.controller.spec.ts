import { Test, TestingModule } from '@nestjs/testing';
import { StatusController } from './status.controller';
import { StatusService } from './status.service';
import { PrismaClient, Status } from '@prisma/client';

describe('StatusController', () => {
  let controller: StatusController;
  let service: StatusService;

  const prismaMock = {
    status: {
      findMany: jest.fn(() => []),
    },
  };

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [StatusController],
      providers: [
        StatusService,
        {
          provide: PrismaClient,
          useValue: prismaMock,
        },
      ],
    }).compile();

    controller = module.get<StatusController>(StatusController);
    service = module.get<StatusService>(StatusService);
  });

//   afterAll(async () => {
//     await prismaMock.$disconnect();
//   });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getAll', () => {
    it('should return an array of statuses', async () => {
      const status: Status[] = [];
      jest.spyOn(service, 'findAll').mockResolvedValue(status);

      expect(await controller.getAll()).toBe(status);
    });

    it('should return an empty array if no statuses found', async () => {
      jest.spyOn(service, 'findAll').mockResolvedValue([]);

      expect(await controller.getAll()).toStrictEqual([]);
    });
  });
});
