import { Module } from "@nestjs/common";
import { StatusService } from "./status.service";
import { PrismaService } from "../prisma/prisma.service";
import { StatusController } from "./status.controller";
import { JwtService } from "@nestjs/jwt";
 
@Module({
    providers: [StatusService, PrismaService, JwtService],
    exports: [StatusService],
    controllers: [StatusController],
})
export class StatusModule {}
