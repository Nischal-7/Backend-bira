import { Module } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { PriorityController } from "./priority.controller";
import { JwtService } from "@nestjs/jwt";
import { PriorityService } from "./priority.service";
 
@Module({
    providers: [PriorityService, PrismaService, JwtService],
    exports: [PriorityService],
    controllers: [PriorityController],
})
export class PriorityModule { }