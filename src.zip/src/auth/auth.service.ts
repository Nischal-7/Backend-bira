import { Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";

@Injectable()
export class AuthService {
    constructor(private jwtService: JwtService) {

    }

    async login(user: string): Promise<any> {
        return {
            acess_token: this.jwtService.sign({
                user: user, sub: 1
            })
        }
    }

}