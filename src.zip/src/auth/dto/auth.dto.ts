import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsString, Length } from "class-validator";

export class AuthDto{

    public id:number



    @ApiProperty()
    public first_name:string

    @ApiProperty()
    public last_name:string

    @ApiProperty()
    public role:string

    @IsNotEmpty()
    @IsString()
    @IsEmail()
    @ApiProperty()
    public email:string



    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    @Length(3,20,{message:'Password mus be bewteen 3 to 20 chars'})
    public password :string

    @IsNotEmpty()
    @ApiProperty()
    public teamId :number
}

