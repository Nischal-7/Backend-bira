import { ApiProperty } from "@nestjs/swagger"
import { IsDate, IsNotEmpty, IsNumber, IsString } from "class-validator"

export class IssueUpdateDto{

        public Id:number
    
        @ApiProperty()
        public title:string;
    
        @ApiProperty()
        public description:string;
    
    
        @ApiProperty()
        public assigneeId:number
    
    
        @ApiProperty()
        public reporterId:number
    
        @ApiProperty()
        public typeId:number
    
        @ApiProperty()
        public statusId:number
    
    
        @ApiProperty()
        public priorityId:number
    
    
        @ApiProperty()
        public start_date:Date
    
    
        @ApiProperty()
        public end_date:Date
    
    
        @ApiProperty()
        public epicId:number
        
    
}