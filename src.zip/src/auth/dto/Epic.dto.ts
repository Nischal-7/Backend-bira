import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsEmail, IsNotEmpty, IsNumber, IsString, Length, isNumber } from "class-validator";

export class EpicDto {

    public id: number

    @IsNotEmpty()
    @ApiProperty()
    @IsString()
    public title: string

    @ApiProperty()
    @IsNumber()
    public statusId: number

    @ApiProperty()
    public description: string

    @ApiProperty()
    public start_date: Date

    @ApiProperty()
    public end_date: Date

    @ApiProperty()
    public created_on: Date

    @ApiProperty()
    public updated_on: Date

    @IsNotEmpty()
    @ApiProperty()
    @IsNumber()
    public projectId: number

    
}


