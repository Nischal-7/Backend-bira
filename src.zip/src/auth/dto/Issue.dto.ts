import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsEmail, IsNotEmpty, IsNumber, IsString, Length } from "class-validator";

export class IssueDto{

    public Id:number

    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    public title:string

    @IsString()
    @ApiProperty()
    @IsNotEmpty()
    public description:string


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public assigneeId:number


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public reporterId:number

    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public typeId:number

    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public statusId:number


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public priorityId:number


    @IsDate()
    @ApiProperty()
    public start_date:Date


    @IsDate()
    @ApiProperty()
    public end_date:Date


    @IsDate()
    @ApiProperty()
    @IsNotEmpty()
    public epicId:number
    
}

