import { Injectable } from '@nestjs/common';
import { Prisma, Issue, User } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
import * as bcrypt from "bcrypt";
import e from 'express';
import { retry } from 'rxjs';
import { IssueUpdateDto } from '../dto/Update.Issue.dto';
import { IssueDto } from '../dto/Issue.dto';
import { EpicService } from 'src/Epic/epic.service';

const salt = process.env.salt;

@Injectable()
export class IssueService {
    constructor(private prisma: PrismaService, private readonly epicService: EpicService) { }

    async insertData(data: IssueDto, req, res) {
        try {
            const present_assigned_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            const present_reporter_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            const present_type_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            const present_status_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            const present_priority_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            const present_epic_id_ = await this.prisma.user.findUnique({
                where: { Id: data.assigneeId }
            })
            if (present_assigned_id_ && present_epic_id_ && present_priority_id_ && present_reporter_id_ && present_status_id_ && present_type_id_) {
                const result = await this.prisma.issue.create({
                    data: {
                        title: data.title,
                        description: data.description,
                        assigneeId: data.assigneeId,
                        reporterId: data.reporterId,
                        typeId: data.typeId,
                        statusId: data.statusId,
                        priorityId: data.priorityId,
                        start_date: data.start_date,
                        end_date: data.end_date,
                        epicId: data.epicId
                    }
                })

                return res.status(200).send({
                    message: "Success",
                    response: result
                })
            }
            else {
                return res.status(201).send({
                    message: "Failure",
                    response: "ID is missing"
                })

            }
        } catch (e) {
            return res.send(404).status({
                message: "Error Occured",
                response: e
            })
        }
    }

    async findEpicById(id: number, req, res): Promise<Issue | object> {
        try {
            const result = await this.prisma.issue.findUnique({
                where: { Id: id },
                // include: { priority }    
            })
            if (!result) {
                return res.status(201).send({
                    message: "Failure",
                    response: "ID is not present"
                })
            }
            else {
                return res.status(200).send({
                    message: "Success",
                    response: result
                })
            }
        } catch (e) {
            return res.status(404).send({
                message: "Failure",
                response: e
            })
        }
    }

    async getIssueAll(req, res) {
        try {
            const result = await this.prisma.issue.findMany({
                include: {
                    assignee_Id: {
                        select: {
                            first_name: true,
                            last_name: true,
                            role: true
                        }
                    }
                }
            })
            return res.status(200).send({
                message: "Success",
                response: result
            })
        } catch (e) {
            return res.status(404).send({
                message: "Failure",
                response: e
            })
        }
    }

    async UpdateDataPatch(id: number, data: IssueUpdateDto, req, res) {
        try {

            const result = await this.prisma.issue.update({
                where: { Id: id },
                data
            })

            if (!result) {
                return res.status(200).send({
                    message: "Failure",
                    response: "Id is not present"
                })
            }
            else {
                return res.status(200).send({
                    message: "Success",
                    response: result
                })
            }
        } catch (e) {
            return res.status(404).send({
                message: "Failure",
                response: e
            })
        }
    }

    async deleteIssueById(id: number, req, res) {
        try {
            const result = await this.prisma.issue.findUnique({
                where: { Id: id },
            })
            if (!result) {
                return res.status(200).send({
                    message: "Failure",
                    response: "Id is not present"
                })
            }
            else {
                console.log("id", id)
                const result = await this.prisma.issue.delete({ where: { Id: id } })
                console.log("data", result);
                return res.status(200).send({
                    message: "Success",
                    response: result
                })

            }
        } catch (e) {
            return res.status(404).send({
                message: "Failure",
                response: e
            })
        }
    }


    async issueFilter(data: IssueUpdateDto, req, res) {
        try {
            const selected_filtered_data = await this.prisma.issue.findMany({
                where: data
            })
            return res.status(200).send({
                message: "Sucess",
                res: selected_filtered_data
            })
        } catch (e) {
            return res.status(400).send(
                {
                    message: "Error Occured",
                    response: e
                }
            )
        }
    }

    async getIssueWithProjectId(id: number, req, res) {
        try {
            const EPICS = await this.epicService.getByProjectIdData(id, req, res)
            const epics = EPICS["response"]
            const epic_ids = epics.map((epic) => {
                return epic.id
            })
            let issue_objects = []
            for (let i = 0; i < epic_ids.length; i++) {
                const epic_id = epic_ids[i]
                const issues = await this.prisma.epic.findUnique({ where: { Id: epic_id }, include: { Issue: {} } })
                for (let i = 0; i < issues["issue"].length; i++) {
                    issue_objects.push(issues["issue"][i])
                }
            }
            return res.status(200).send(
                {
                    message: "Success",
                    response: issue_objects
                }
            )
        }
        catch (e) {
            return res.status(200).send(
                {
                    message: "Failure",
                    response: e
                }
            )
        }
    }
}