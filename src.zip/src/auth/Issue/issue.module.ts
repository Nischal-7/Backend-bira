 
import { Module } from "@nestjs/common";
import { IssueService } from "./issue.service";

import { IssueController } from "./issue.controller";
import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "src/prisma/prisma.service";
import { EpicService } from "src/Epic/epic.service";
import { UserService } from "src/User/user.service";

 
@Module({
    providers: [IssueService, PrismaService, JwtService, EpicService, UserService],
    exports: [IssueService],
    controllers: [IssueController],
})
export class IssueModule { }