import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Observable } from 'rxjs';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') implements CanActivate {
    canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        return super.canActivate(context);
    }
}


/*
async canActivate(context: ExecutionContext): Promise<boolean>{
        
        return true;
    }

import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/pas AppModule implements NestModule {
//   constructor(private readonly auditLogsService: AuditLogsService) { }

//   configure(consumer: MiddlewareConsumer) {
//     consumer.apply(AuditMiddleware).forRoutes('*');
//   }
// }ssport';
import { Observable } from 'rxjs';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') implements CanActivate {
  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    return super.canActivate(context);
  }
}


Ratelimiter/throter,

*/