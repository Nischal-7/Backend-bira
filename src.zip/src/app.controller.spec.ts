// import { Test, TestingModule } from '@nestjs/testing';
// import { AppController } from './app.controller';
// import { AppService } from './app.service';

// describe('AppController', () => {
//   let appController: AppController;

//   beforeEach(async () => {
//     const app: TestingModule = await Test.createTestingModule({
//       controllers: [AppController],
//       providers: [AppService],
//     }).compile();

//     appController = app.get<AppController>(AppController);
//   });

//   describe('root', () => {
//     it('should return "Hello World!"', () => {
//       expect(appController.getHello()).toBe('Hello World!');
//     });
//   });
// });

import { Test, TestingModule } from '@nestjs/testing';
import { Controller, Request, Post, UseGuards, Get, Body, Req, Res } from "@nestjs/common";
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthService } from "./auth/auth.service";
import { AuthDto } from "./auth/dto/auth.dto";
import { ApiTags } from "@nestjs/swagger";
import { LoginDto } from "./auth/dto/login.dto";

describe('AppController', () => {
  let appController: AppController;
  let appService: AppService;

  beforeEach(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [AppService],
    }).compile();

    appService = moduleRef.get<AppService>(AppService);
    appController = moduleRef.get<AppController>(AppController);
  });

  describe('checkEnvirontment', () => {
    it('should return the environment value', async () => {
      const result = await appController.checkEnvirontment();
      expect(result).toBeDefined();
    });
  });

  describe('signIn', () => {
    it('should sign in a user and return a response', async () => {
      const loginDto: LoginDto = {id:Date.now(), email: 'johndoe', password: 'secret' };
      const req = { session: {} };
      const res = {
        cookie: jest.fn(),
        send: jest.fn(),
        status: jest.fn().mockReturnThis(),
      };
      const result = await appController.signIn(loginDto, req, res);
      expect(result).toBeDefined();
      expect(res.cookie).toHaveBeenCalled();
      expect(res.send).toHaveBeenCalled();
    });
  });

  describe('signOut', () => {
    it('should sign out a user and return a response', async () => {
      const req = { session: { destroy: jest.fn() } };
      const res = {
        clearCookie: jest.fn(),
        send: jest.fn(),
        status: jest.fn().mockReturnThis(),
      };
      const result = await appController.signOut(req, res);
      expect(result).toBeDefined();
      expect(req.session.destroy).toHaveBeenCalled();
      expect(res.clearCookie).toHaveBeenCalled();
      expect(res.send).toHaveBeenCalled();
    });
  });
});
