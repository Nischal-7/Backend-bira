import { Module } from "@nestjs/common";


// import { UserModule } from "./user/user.module";

// import { TeamModule } from "./team/team.module";

import { ConfigModule } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "src/prisma/prisma.module";
import { ProjectController } from "./project.controller";
import { ProjectService } from "./project.service";
import { JwtStrategy } from "src/auth/jwt.strategy";

@Module({
  imports: [
    // ConfigModule.forRoot({isGlobal: true}),
    // UserModule,
    // TeamModule,
    JwtModule,
    PrismaModule
  ],

  controllers: [ProjectController],
  providers: [ProjectService,JwtStrategy],
})
export class ProjectModule {}
