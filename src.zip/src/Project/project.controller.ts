import { Controller, Request, Post, UseGuards, Get, Body, Req, Res, Param, Patch, Delete } from "@nestjs/common";
import { ApiBody, ApiTags } from "@nestjs/swagger";
import { ProjectService } from "./project.service";
import { ProjectDto } from "src/auth/dto/project.dto";

@ApiTags("Project")
@Controller('projects')
export class ProjectController {


    constructor(private readonly projectService: ProjectService) { }

    @Get(':id')
    getProject(
        @Param('id') id: number,
        @Req() req, @Res() res
    ) {
        id = Number(id)
        return this.projectService.getProjectById(id, req, res);
    }

    @Patch(':id')
    @ApiBody({
        schema: {
            type: 'object',
            properties: {
              title: { type: 'string', },
              description: { type: 'string', },
              start_date: { type: 'string',
              format: 'date-time' },
              end_date: { type: 'string',
              format: 'date-time' },
              ownerId: { type: 'number', },
            }
          }
    })
    updateWithPatch(
        @Param('id') id: number,
        @Body() _project: { id: number, title?: string, description?: string, start_date?: Date, end_date?: Date, ownerId?: number, teamId: number },
        @Req() req, @Res() res
    ) {
        id = Number(id)
        return this.projectService.updatePatch(_project, id, req, res);
    }

    @Delete(':id')
    deleteProject(
        @Param('id') id: number,
        @Req() req, @Res() res
    ) {
        id = Number(id)
        return this.projectService.deleteById(id, req, res);
    }


    @Get()
    getAll(@Req() req, @Res() res) {
        return this.projectService.getAllProject(req, res);
    }


    @Post()
    addProject(
        @Body() _project: ProjectDto,
        @Req() req, @Res() res) {

        return this.projectService.insertProject(_project, req, res);
    }


}
