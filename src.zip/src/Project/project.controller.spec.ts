import { Test, TestingModule } from '@nestjs/testing';
import { ProjectController } from './project.controller';
import { ProjectService } from './project.service';

describe('ProjectController', () => {
  let controller: ProjectController;
  let service: ProjectService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ProjectController],
      providers: [ProjectService],
    }).compile();

    controller = module.get<ProjectController>(ProjectController);
    service = module.get<ProjectService>(ProjectService);
  });

  describe('getProject', () => {
    it('should call projectService.getProjectById with the given id, req, and res', async () => {
      const id = 1;
      const req = {};
      const res = {};

      jest.spyOn(service, 'getProjectById').mockImplementation(() => Promise.resolve());

      await controller.getProject(id, req, res);

      expect(service.getProjectById).toHaveBeenCalledWith(id, req, res);
    });
  });

  describe('updateWithPatch', () => {
    it('should call projectService.updatePatch with the given project, id, req, and res', async () => {
      const id = 1;
      const project = {
        id: 1,
        title: 'New Project Title',
        description: 'New Project Description',
        start_date: new Date(),
        end_date: new Date(),
        ownerId: 1,
        teamId: 1,
      };
      const req = {};
      const res = {};

      jest.spyOn(service, 'updatePatch').mockImplementation(() => Promise.resolve());

      await controller.updateWithPatch(id, project, req, res);

      expect(service.updatePatch).toHaveBeenCalledWith(project, id, req, res);
    });
  });

  describe('deleteProject', () => {
    it('should call projectService.deleteById with the given id, req, and res', async () => {
      const id = 1;
      const req = {};
      const res = {};

      jest.spyOn(service, 'deleteById').mockImplementation(() => Promise.resolve());

      await controller.deleteProject(id, req, res);

      expect(service.deleteById).toHaveBeenCalledWith(id, req, res);
    });
  });

  describe('getAll', () => {
    it('should call projectService.getAllProject with the given req and res', async () => {
      const req = {};
      const res = {};

      jest.spyOn(service, 'getAllProject').mockImplementation(()=>void);

      await controller.getAll(req, res);

      expect(service.getAllProject).toHaveBeenCalledWith(req, res);
    });
  });

  describe('addProject', () => {
    it('should call projectService.insertProject with the given project, req, and res', async () => {
      const project = {
        id: 1,
        title: 'New Project Title',
        description: 'New Project Description',
        start_date: new Date(),
        end_date: new Date(),
        ownerId: 1,
        teamId: 1,
      };
      const req = {};
      const res = {};

      jest.spyOn(service, 'insertProject').mockImplementation(() => Promise.resolve());

      await controller.addProject(project, req, res);

      expect(service.insertProject).toHaveBeenCalledWith(project, req, res);
    });
  });
});
