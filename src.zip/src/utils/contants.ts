require("dotenv").config();
export const jwtSecret=process.env.JWT_SECRET
export const DATABASE_URL=process.env.DATABASE_URL