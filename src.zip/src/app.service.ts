import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from './prisma/prisma.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { jwtSecret } from './utils/contants';
import { Request, Response } from 'express';
import { LoginDto } from './auth/dto/login.dto';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }

  constructor(private prisma: PrismaService, private jwt: JwtService) { }


  async signin(dto: LoginDto, req: Request, res: Response) {
    const { email, password } = dto
    const foundUser = await this.prisma.user.findUnique({ where: { email } })

    if (!foundUser) {
      res.status(200).send({
        message: "user not found"
      })
    }

    // delete user.hashedPassword;
    const isMatch = await this.comparePassword({ password, hash: foundUser.hashPassword })
    if (!isMatch) {
      return res.status(200).send({
        message: "user not found"
      })
    }

    const token = await this.signToken({
      id: foundUser.Id,
      username: foundUser.email
    });
    if (!token) {
      return res.status(200).send({
        message: "user not found"
      })
    }

    res.cookie('token', token)
    return res.status(200).send({
      token: token,
      message: "Logged in sucessfully",
      user: foundUser
    });

  }


  async signout(req: Request, res: Response) {
    res.clearCookie('token')
    return res.send({ mesage: 'Logged out scucessfully' })

  }

  async hashedPassword(password: string) {
    const saltOrRound = 10
    const hashPassword = await bcrypt.hash(password, saltOrRound)
    return hashPassword;
  }
  async comparePassword(args: { password: string, hash: string }) {
    return await bcrypt.compare(args.password, args.hash);
  }


  async signToken(args: { id: number, username: string }) {
    const payload = args
    return this.jwt.signAsync(payload)
  }



}
