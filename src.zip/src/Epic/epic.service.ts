import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { Request, Response } from 'express';
import { PrismaService } from 'src/prisma/prisma.service';
import { EpicDto } from 'src/auth/dto/Epic.dto';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class EpicService {



    constructor(private prisma: PrismaService) { }

    async insertEpicData(_epic: EpicDto, req: Request, res: Response) {
        try {
            const foundUser = await this.prisma.epic.findUnique({ where: { title: _epic.title } })
            if (foundUser) {
                throw new BadRequestException('Title already exists')
            }
            else {
                const prisma = new PrismaClient()
                const result = await prisma.epic.create({
                    data: _epic
                })
                return res.status(200).send({ message: 'Data Inserted Sucessfully', data: result })
            }
        }
        catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })

        }
    }
    getDataFromPage(page: number, req: Request, res: Response) {
        throw new Error("Method not implemented.");
    }
    async getByProjectIdData(projectId: number, req: Request, res: Response) {
        try {
            const getByProject = await this.prisma.epic.findMany({
                where: { projectId: projectId },
                include: {
                    Issue: {}
                }
            })
            if (getByProject.length) {
                return res.status(201).send({
                    message: "Sucess",
                    res: getByProject
                })
            } else {
                return res.status(400).send({
                    message: "Failure",
                    res: "Project Id is doesn't exist"
                })
            }
        } catch (e) {
            return res.status(400).send({
                message: "Error Occured",
                error: e
            })
        }
    }



    async deleteEpicDataById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.epic.delete({ where: { Id: id } })
            if (result)
                res.status(200).send({ deletedEpic: result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }



    updatePathDataById(id: number, req: Request, res: Response) {
        throw new Error("Method not implemented.");
    }


    async getDataById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.epic.findUnique({
                where: { Id: id }
            })
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }








}
