import { Controller, Request, Post, UseGuards, Get, Body, Req, Res, Param, Patch, Delete } from "@nestjs/common";
import { ApiBody, ApiTags } from "@nestjs/swagger";
import { TeamDto } from "src/auth/dto/team.dto";
import { EpicService } from "./epic.service";
import { EpicDto } from "src/auth/dto/Epic.dto";


@ApiTags("Epic")
@Controller('epic')
export class EpicController {


    constructor(private readonly epicService: EpicService) { }


    @Get(':id')
    getEpicById(
        @Param("id") id: number,
        @Req() req, @Res() res,
    ) {
        return this.epicService.getDataById(id, req, res)
    }




    @Patch(':id')
    @ApiBody({
        schema: {
            type: 'object',
            properties: {
              title: { type: 'string', },
              statusId: { type: 'number', },
              description: { type: 'string', },
              start_date: { type: 'string',
              format: 'date-time' },
              end_date: { type: 'string',
              format: 'date-time' },
              created_on:{type: 'string',
              format: 'date-time'},
              updated_on:{type: 'string',
              format: 'date-time'},
              projectId:{type:'number'},
            }
          }
    })
    updatePartialData(
        @Param('id') id: number,
        @Body() _data: {
            title?: string, statusId?: number,
            description?: string, start_date?: Date,
            end_date?: Date, created_on?: Date,
            updated_on: Date, projectId?: number,

        },
        @Req() req, @Res() res,
    ) {
        return this.epicService.updatePathDataById(id, req, res)
    }


    @Delete(':id')
    deleteEpicData(
        @Param('id')id:number,
        @Req() req, @Res() res,
    ){
        return this.epicService.deleteEpicDataById(id,req,res);
    }


    @Get("/byProjectId/:projectId")
    getProjectData(
        @Param(':projectId')projectId:number,
        @Req() req, @Res() res,
    ){
        return this.epicService.getByProjectIdData(projectId,req,res)
    }



    @Get()
    getPagination(
        @Param('page')page:number,
        @Req() req, @Res() res,
    ){
        return this.epicService.getDataFromPage(page,req,res);
    }



    @Post()
    addTeam(@Body() _epic: EpicDto, @Req() req, @Res() res) {
        return this.epicService.insertEpicData(_epic, req, res);
    }

}
