import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "src/prisma/prisma.module";
import { EpicController } from "./epic.controller";
import { EpicService } from "./epic.service";
import { JwtStrategy } from "src/auth/jwt.strategy";

@Module({
  imports: [
    // ConfigModule.forRoot({isGlobal: true}),
    // UserModule,
    // TeamModule,
    JwtModule,
    PrismaModule
  ],

  controllers: [EpicController],
  providers: [EpicService,JwtStrategy],
})
export class EpicModule {}
